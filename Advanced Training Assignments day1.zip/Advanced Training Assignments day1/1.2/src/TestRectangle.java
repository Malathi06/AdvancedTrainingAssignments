public class TestRectangle {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(5,6);
		r1.printData();
		r1.printArea();
		r1.printPerimeter();


		r2.printData();
		r2.printArea();
		r2.printPerimeter();
		;


	}
}